package com.solecthon.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
