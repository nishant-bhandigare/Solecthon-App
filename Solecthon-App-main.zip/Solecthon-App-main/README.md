# Solecthon's Mobile Application

A mobile application to transfer real-time vehicle data to nearby devices. This application also helps to control the autonomous feature in case of breakdown.

