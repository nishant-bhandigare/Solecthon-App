import 'package:flutter/material.dart';

class BluetoothLandingPage extends StatefulWidget {
  const BluetoothLandingPage({Key? key}) : super(key: key);

  @override
  State<BluetoothLandingPage> createState() => _BluetoothLandingPageState();
}

class _BluetoothLandingPageState extends State<BluetoothLandingPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
